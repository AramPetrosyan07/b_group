import './App.css';
import Page404 from './component/404_page/Page404';

function App() {
  return (
    <div className="App">
      <Page404 />
    </div>
  );
}

export default App;
