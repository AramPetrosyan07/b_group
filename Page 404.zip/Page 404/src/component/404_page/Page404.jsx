import Page404Css from "./Page404.module.css"
import { AiOutlineArrowRight } from "react-icons/ai";

function Page404() {
   window.location = "localhost:3000/Page404"
   return (
      <div className={Page404Css.main}>
         <div className={Page404Css.information}>
            <div className={Page404Css.heading}></div>
            <p className={Page404Css.notFound}>Page not found</p>
            <p className={Page404Css.pageExist}>The page you are looking for doesn't exist or has been moved</p>
            <button className={Page404Css.btn}
               onClick={() => {
                  window.location = "localhost:3000/"
               }}>Go to Homepage
               <div className={Page404Css.arrowBg}>
                  <AiOutlineArrowRight className={Page404Css.arrowIcon} />
               </div>
            </button>
         </div>
      </div>
   )
}

export default Page404